-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 18, 2018 at 07:31 PM
-- Server version: 10.0.36-MariaDB
-- PHP Version: 7.1.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sbadlt_egidijus`
--

-- --------------------------------------------------------

--
-- Table structure for table `auto`
--

CREATE TABLE `auto` (
  `id` int(11) NOT NULL,
  `auto_name` varchar(255) COLLATE utf8_lithuanian_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_lithuanian_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_lithuanian_ci NOT NULL,
  `number` int(11) NOT NULL,
  `content` text COLLATE utf8_lithuanian_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_lithuanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

--
-- Dumping data for table `auto`
--

INSERT INTO `auto` (`id`, `auto_name`, `first_name`, `last_name`, `number`, `content`, `email`) VALUES
(13, 'honda', 'Egidijus', 'Balciunas', 868686868, 'Pilnas kuro bakas', 'egidijusss.15@gmail.com'),
(14, 'audi', 'Tomas', 'Tomukas', 868686868, 'Nieko nereikia.', 'tomas@gmail.com'),
(15, 'bmw', 'Petras', 'Petriukas', 868686868, 'Pilnas kuro bakas.', 'petras@gmail.com'),
(16, 'volvo', 'Juozas', 'Juozukas', 868686868, '', 'juozas@gmail.com'),
(17, 'bentley', 'Antanas', 'Antanukas', 868686868, 'Nieko nereikia.', 'antanas@gmail.com'),
(18, 'jaguar', 'Jonas', 'Jonukas', 868686868, 'Papildomo draudimo zmogui neturinciam 25 metu.', 'jonas@gmail.com'),
(19, 'mercedes', 'Kazys', 'Kaziukas', 868686868, '', 'kazys@gmail.com'),
(20, 'ford', 'Mantas', 'Mantukas', 868686868, 'Pilno kuro bako.', 'mantas@gmail.com'),
(21, 'lexus', 'Lukas', 'Lukiukas', 868686868, 'Nieko nereikia.', 'lukas@gmail.com'),
(22, 'honda', 'Pranas', 'Praniukas', 868686868, 'Reikia papildomai vaiko kedutes', 'pranas@gmail.com'),
(23, 'honda', 'Egidijus', 'Balciunas', 868686868, 'Pilnas kuro bakas', 'egidijusss.15@gmail.com'),
(24, 'audi', 'Tomas', 'Tomukas', 868686868, 'Nieko nereikia.', 'tomas@gmail.com'),
(25, 'bmw', 'Petras', 'Petriukas', 868686868, 'Pilnas kuro bakas.', 'petras@gmail.com'),
(26, 'volvo', 'Juozas', 'Juozukas', 868686868, '', 'juozas@gmail.com'),
(27, 'bentley', 'Antanas', 'Antanukas', 868686868, 'Nieko nereikia.', 'antanas@gmail.com'),
(28, 'jaguar', 'Jonas', 'Jonukas', 868686868, 'Papildomo draudimo zmogui neturinciam 25 metu.', 'jonas@gmail.com'),
(29, 'mercedes', 'Kazys', 'Kaziukas', 868686868, '', 'kazys@gmail.com'),
(30, 'ford', 'Mantas', 'Mantukas', 868686868, 'Pilno kuro bako.', 'mantas@gmail.com'),
(31, 'lexus', 'Lukas', 'Lukiukas', 868686868, 'Nieko nereikia.', 'lukas@gmail.com'),
(32, 'honda', 'Pranas', 'Praniukas', 868686868, 'Reikia papildomai vaiko kedutes', 'pranas@gmail.com'),
(33, 'honda', 'Egidijus', 'Balciunas', 868686868, 'Pilnas kuro bakas', 'egidijusss.15@gmail.com'),
(34, 'audi', 'Tomas', 'Tomukas', 868686868, 'Nieko nereikia.', 'tomas@gmail.com'),
(35, 'bmw', 'Petras', 'Petriukas', 868686868, 'Pilnas kuro bakas.', 'petras@gmail.com'),
(36, 'volvo', 'Juozas', 'Juozukas', 868686868, '', 'juozas@gmail.com'),
(37, 'bentley', 'Antanas', 'Antanukas', 868686868, 'Nieko nereikia.', 'antanas@gmail.com'),
(38, 'jaguar', 'Jonas', 'Jonukas', 868686868, 'Papildomo draudimo zmogui neturinciam 25 metu.', 'jonas@gmail.com'),
(39, 'mercedes', 'Kazys', 'Kaziukas', 868686868, '', 'kazys@gmail.com'),
(40, 'ford', 'Mantas', 'Mantukas', 868686868, 'Pilno kuro bako.', 'mantas@gmail.com'),
(41, 'lexus', 'Lukas', 'Lukiukas', 868686868, 'Nieko nereikia.', 'lukas@gmail.com'),
(42, 'honda', 'Pranas', 'Praniukas', 868686868, 'Reikia papildomai vaiko kedutes', 'pranas@gmail.com'),
(43, 'honda', 'Egidijus', 'Balciunas', 868686868, 'Pilnas kuro bakas', 'egidijusss.15@gmail.com'),
(44, 'audi', 'Tomas', 'Tomukas', 868686868, 'Nieko nereikia.', 'tomas@gmail.com'),
(45, 'bmw', 'Petras', 'Petriukas', 868686868, 'Pilnas kuro bakas.', 'petras@gmail.com'),
(46, 'volvo', 'Juozas', 'Juozukas', 868686868, '', 'juozas@gmail.com'),
(47, 'bentley', 'Antanas', 'Antanukas', 868686868, 'Nieko nereikia.', 'antanas@gmail.com'),
(48, 'jaguar', 'Jonas', 'Jonukas', 868686868, 'Papildomo draudimo zmogui neturinciam 25 metu.', 'jonas@gmail.com'),
(49, 'mercedes', 'Kazys', 'Kaziukas', 868686868, '', 'kazys@gmail.com'),
(50, 'ford', 'Mantas', 'Mantukas', 868686868, 'Pilno kuro bako.', 'mantas@gmail.com'),
(51, 'lexus', 'Lukas', 'Lukiukas', 868686868, 'Nieko nereikia.', 'lukas@gmail.com'),
(52, 'honda', 'Pranas', 'Praniukas', 868686868, 'Reikia papildomai vaiko kedutes', 'pranas@gmail.com'),
(53, 'honda', 'Egidijus', 'Balciunas', 868686868, 'Pilnas kuro bakas', 'egidijusss.15@gmail.com'),
(54, 'audi', 'Tomas', 'Tomukas', 868686868, 'Nieko nereikia.', 'tomas@gmail.com'),
(55, 'bmw', 'Petras', 'Petriukas', 868686868, 'Pilnas kuro bakas.', 'petras@gmail.com'),
(56, 'volvo', 'Juozas', 'Juozukas', 868686868, '', 'juozas@gmail.com'),
(57, 'bentley', 'Antanas', 'Antanukas', 868686868, 'Nieko nereikia.', 'antanas@gmail.com'),
(58, 'jaguar', 'Jonas', 'Jonukas', 868686868, 'Papildomo draudimo zmogui neturinciam 25 metu.', 'jonas@gmail.com'),
(59, 'mercedes', 'Kazys', 'Kaziukas', 868686868, '', 'kazys@gmail.com'),
(60, 'ford', 'Mantas', 'Mantukas', 868686868, 'Pilno kuro bako.', 'mantas@gmail.com'),
(61, 'lexus', 'Lukas', 'Lukiukas', 868686868, 'Nieko nereikia.', 'lukas@gmail.com'),
(62, 'honda', 'Pranas', 'Praniukas', 868686868, 'Reikia papildomai vaiko kedutes', 'pranas@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auto`
--
ALTER TABLE `auto`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auto`
--
ALTER TABLE `auto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
